"use strict"

function toggleMenu() {
    let menuBox = document.getElementById('menubox');
    menuBox.classList.toggle('active');
}

